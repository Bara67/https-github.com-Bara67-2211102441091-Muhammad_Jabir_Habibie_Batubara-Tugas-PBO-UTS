import greenfoot.*;

public class SnakeHead extends Actor {
    private static final int RIGHT = 0;
    private static final int DOWN = 90;
    private static final int LEFT = 180;
    private static final int UP = 270;

    private static final int SPEED = 15;
    private int counter = 0;
    private int foodEaten = 0;

    public void moveAround() {
        counter++;
        if (counter == SPEED) {
            getWorld().addObject(new Body(foodEaten * SPEED), getX(), getY());
            move(15);
            counter = 0;
        }
        checkKeyPress();
    }

    public void checkKeyPress() {
        if (Greenfoot.isKeyDown("up") && getRotation() != DOWN) {
            setRotation(UP);
        } else if (Greenfoot.isKeyDown("down") && getRotation() != UP) {
            setRotation(DOWN);
        } else if (Greenfoot.isKeyDown("left") && getRotation() != RIGHT) {
            setRotation(LEFT);
        } else if (Greenfoot.isKeyDown("right") && getRotation() != LEFT) {
            setRotation(RIGHT);
        }
    }

    private boolean facingEdge() {
        int x = getX();
        int y = getY();
        return x >= getWorld().getWidth() - 1 || y >= getWorld().getHeight() - 1 || x <= 0 || y <= 0;
    }

    public void act() {
        moveAround();
        if (isTouching(Food.class)) {
            Food food = (Food) getOneIntersectingObject(Food.class);
            foodEaten++;
            getWorld().removeObject(food);
            SnakeWorld world = (SnakeWorld) getWorld();
            world.addFood();
        }

        if (facingEdge()) {
            Greenfoot.stop();
        }
    }
}
