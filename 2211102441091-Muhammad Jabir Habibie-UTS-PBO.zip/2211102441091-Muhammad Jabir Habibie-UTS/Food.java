import greenfoot.*;

public class Food extends Actor {
    private SnakeWorld myWorld;

    public Food(SnakeWorld world) {
        myWorld = world;
    }

    public void act() {
        checkCollision();
    }

    private void checkCollision() {
        SnakeHead snake = (SnakeHead) getOneIntersectingObject(SnakeHead.class);
        if (snake != null) {
            getWorld().removeObject(this);
        }
    }
}
